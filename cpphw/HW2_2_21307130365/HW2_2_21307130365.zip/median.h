#ifndef guard_median
#define guard_median

#include<algorithm>
#include<vector>
#include<stdexcept>
double median(std::vector<double> vec);

#endif