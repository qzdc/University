#include"student_info.h"

inline double grade(double mid, double fin, double hw) {
	return mid * 0.2 + fin * 0.4 + hw * 0.4;
}
double grade(double, double, std::list<double>&);
double grade(stdif&);