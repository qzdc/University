#ifndef guard_median
#define guard_median

#include<algorithm>
#include<list>
#include<stdexcept>
double median(std::list<double> vec);

#endif